OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(sens_standardized) == 2000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(np.mean(sens_standardized), 0)\nnp.True_', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(np.std(sens_standardized, ddof=1), 1)\nnp.True_', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
