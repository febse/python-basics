OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> number_of_laptops == 991\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(average_rating, 63.9313824419778)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> number_of_dell_laptops == 106\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> number_of_brands == 26\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(share_of_laptops_with_more_than_4_cores, 0.7759838546922301)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(average_price_by_number_of_cores.iloc[0], 28520.05)\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(average_price_by_number_of_cores) == 12\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
