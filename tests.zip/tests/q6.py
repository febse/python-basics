OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> number_of_laptops == 991\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(average_rating, 63.9313824419778)\nnp.True_', 'hidden': False, 'locked': False},
                                   {'code': '>>> number_of_dell_laptops == 106\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> number_of_brands == 26\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(share_of_laptops_with_more_than_4_cores, 0.7759838546922301)\nnp.True_', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
