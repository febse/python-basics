OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> earnings_sam == 24391.22\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> earnings_average == 23512.53\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> report_sam == "Samuel\'s earnings are 878.69 higher than the average."\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
