OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(probs) == len(unnormed)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(probs.sum(), 1)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
