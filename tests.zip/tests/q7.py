OK_FORMAT = True

test = {   'name': 'q7',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> np.isclose(laptops['price_in_euro'][0], 263.89)\nnp.True_", 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(average_price_in_euro, 849.9315499495459)\nnp.True_', 'hidden': False, 'locked': False},
                                   {'code': ">>> laptops['price_category'][0] == 'medium'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> laptops['price_category'][5] == 'high'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> laptops['price_category'][70] == 'low'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> len(number_of_laptops_in_price_category) == 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> number_of_laptops_in_price_category['medium'] == 504\nnp.True_", 'hidden': False, 'locked': False},
                                   {'code': ">>> number_of_laptops_in_price_category['low'] == 14\nnp.True_", 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(laptops['price_per_core'][0], 131.945)\nnp.True_", 'hidden': False, 'locked': False},
                                   {'code': ">>> brand_with_highest_average_price_per_core == 'apple'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
