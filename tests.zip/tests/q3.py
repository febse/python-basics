OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> def test_a(a):\n'
                                               '...     assert a[0] == 0\n'
                                               '...     assert a[1] == 1\n'
                                               '...     assert a[2] == 2\n'
                                               '...     assert a[3] == 3\n'
                                               '...     assert a[4] == 4\n'
                                               '...     assert a[5] == 5\n'
                                               '...     assert a[6] == 6\n'
                                               '...     assert a[7] == 7\n'
                                               '...     assert a[8] == 8\n'
                                               '...     assert a[9] == 9\n'
                                               '...     assert a[10] == 10\n'
                                               '...     assert a[100] == 100\n'
                                               '...     assert a[1000] == 1000\n'
                                               '...     assert a[-1] == 10000\n'
                                               '>>> test_a(a)\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> def test_b(b):\n...     assert b[0] == 1\n...     assert b[1] == 3\n...     assert b[-1] == 101\n>>> test_b(b)\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> def test_b_squared(b_squared):\n'
                                               '...     assert b_squared[0] == 1\n'
                                               '...     assert b_squared[1] == 9\n'
                                               '...     assert b_squared[-1] == 10201\n'
                                               '>>> test_b_squared(b_squared)\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> def test_x(x):\n'
                                               '...     assert len(x) == 1000\n'
                                               '...     assert x[0] == -2\n'
                                               '...     assert np.isclose(x[1], -1.995995995995996)\n'
                                               '...     assert x[-1] == 2\n'
                                               '>>> test_x(x)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
