OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(earnings) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(earnings, np.array([24391.22, 23512.53, 15342.32, 26342.32, 78342.32])).all()\nnp.True_', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(earnings_bgn, 1.95583 * np.array([24391.22, 23512.53, 15342.32, 26342.32, 78342.32])).all()\nnp.True_', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(earnings_bgn_high) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(earnings_bgn_high, np.array([51521.0997256, 153224.2597256])).all()\nnp.True_', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
